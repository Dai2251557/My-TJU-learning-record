import nn
import numpy as np

class PerceptronModel(object):
    def __init__(self, dimensions):
        # 构建一个1*n(dimensions)的参数列表
        self.w = nn.Parameter(1, dimensions)

    def get_weights(self):
        # 返回现在的参数列表
        return self.w

    def run(self, x):
        # 计算权重向量和给定输入的点积，并返回
        return nn.DotProduct(self.w,x)

    def get_prediction(self, x):
        # 调用run函数计算点积，并转换为Python浮点数
        num=nn.as_scalar(self.run(x))
        if num >=0:
            return 1
        else:
            return -1

    def train(self, dataset):
        while True:
            state=True
            for x,y in dataset.iterate_once(1):
                if self.get_prediction(x)!=nn.as_scalar(y):
                    state=False#本次训练失败，需要根据数据更新权重参数
                    self.w.update(x,nn.as_scalar(y))#这里的想法是：用y充当学习率，共分两种情况：
                    #第一种：x和目标方向成锐角，y值对应为1，这时当前估计方向与x成钝角，这时update让估计向量加上x，可以使得估计向量与目标方向夹角变小
                    #第二种：x和目标方向成钝角，y值对应为-1，这时当前估计方向和x成锐角，这时update让估计向量减去x，可以使得估计向量与目标方向夹角变小
            if state==True:#所有样本训练结束标志仍正确，说明训练数据全部通过，退出循环即可
                break


class RegressionModel(object):
    """
    A neural network model for approximating a function that maps from real
    numbers to real numbers. The network should be sufficiently large to be able
    to approximate sin(x) on the interval [-2pi, 2pi] to reasonable precision.
    """
    def __init__(self):
        # 构造含有一个隐藏层的神经网络：f(x)=relu (x * W1 + b1) * W2 + b2
        # 各参数矩阵的形状如下：
        # x : batches * input_features
        # W1: input_features * hidden_layer_size
        # b1: 1 * hidded_layer_size
        # W2: hidded_layer_size * output_features
        # b2: 1 * output_features
        #初始化各矩阵参数
        #因为这里是拟合sin函数，测试数据为图像上的点（x,y），所以input_features=output_features=1
        self.input_features = 1
        self.output_features = 1
        # hidden_layer_size:10-400之间均可以
        self.hidden_layer_size = 150
        # batches：被数据集总大小整除即可
        self.batches = 20
        # 学习率：0.001-1.0
        self.learning_rate = 0.05
        # 构造各神经网络参数矩阵
        self.W1 = nn.Parameter(self.input_features, self.hidden_layer_size)
        self.b1 = nn.Parameter(1, self.hidden_layer_size)
        self.W2 = nn.Parameter(self.hidden_layer_size, self.output_features)
        self.b2 = nn.Parameter(1, self.output_features)

    def run(self, x):
        # f(x)=relu (x * W1 + b1) * W2 + b2
        # 计算 x * W1 + b1
        hidden_layer_in=nn.AddBias(nn.Linear(x, self.W1), self.b1)
        # 计算 ReLU（x * W1 + b1）
        hidden_layer_out = nn.ReLU(hidden_layer_in)#这也是输出层的输入
        # 计算 ReLU（x * W1 + b1）* W2 + b2
        prediction = nn.AddBias(nn.Linear(hidden_layer_out, self.W2), self.b2)
        return prediction

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        Inputs:
            x: a node with shape (batch_size x 1)
            y: a node with shape (batch_size x 1), containing the true y-values
                to be used for training
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        return nn.SquareLoss(self.run(x), y)

    def train(self, dataset):
        while True:
            all_loss=[]#用来存放每次的均方误差
            for x, y in dataset.iterate_once(self.batches):
                loss = self.get_loss(x, y)
                all_loss.append(nn.as_scalar(loss))
                # 针对四个变量矩阵，计算误差对其的偏导
                gradient_W1, gradient_b1, gradient_W2, gradient_b2 = nn.gradients(loss, [self.W1, self.b1, self.W2, self.b2])
                # 调用 update函数，根据下面的公式调整每个变量矩阵
                # w(i,j)=w(i,j) - alpha * ( 误差对w(i,j)的偏导 )
                self.W1.update(gradient_W1, -1*self.learning_rate)
                self.b1.update(gradient_b1, -1*self.learning_rate)
                self.W2.update(gradient_W2, -1*self.learning_rate)
                self.b2.update(gradient_b2, -1*self.learning_rate)
            if np.mean(all_loss) < 0.010:
                break

class DigitClassificationModel(object):
    """
    A model for handwritten digit classification using the MNIST dataset.

    Each handwritten digit is a 28x28 pixel grayscale image, which is flattened
    into a 784-dimensional vector for the purposes of this model. Each entry in
    the vector is a floating point number between 0 and 1.

    The goal is to sort each digit into one of 10 classes (number 0 through 9).

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # 构造含有一个隐藏层的神经网络：f(x)=relu (x * W1 + b1) * W2 + b2
        # 各参数矩阵的形状如下：
        # x : batches * input_features
        # W1: input_features * hidden_layer_size
        # b1: 1 * hidded_layer_size
        # W2: hidded_layer_size * output_features
        # b2: 1 * output_features
        # 这里题目中明确一个数字的大小为28*28像素（784），即input_features=784
        # 这里题目中明确了输出向量是一组10维的向量,除了对应于正确数字类的位置上的一个其余位置均为0,即output_feature=10
        self.input_feature = 784
        self.output_feature = 10
        self.batch_size = 10
        self.hidden_layer_size=100
        self.W1 = nn.Parameter(self.input_feature, self.hidden_layer_size)
        self.b1 = nn.Parameter(1, self.hidden_layer_size)
        self.W2 = nn.Parameter(self.hidden_layer_size, self.output_feature)
        self.b2 = nn.Parameter(1, self.output_feature)
        self.learning_rate = 0.004

    def run(self, x):

        # f(x)=relu (x * W1 + b1) * W2 + b2
        # 计算 x * W1 + b1
        hidden_layer_in = nn.AddBias(nn.Linear(x, self.W1), self.b1)
        # 计算 ReLU（x * W1 + b1）
        hidden_layer_out = nn.ReLU(hidden_layer_in)  # 这也是输出层的输入
        # 计算 ReLU（x * W1 + b1）* W2 + b2
        prediction = nn.AddBias(nn.Linear(hidden_layer_out, self.W2), self.b2)
        return prediction

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 10). Each row is a one-hot vector encoding the correct
        digit class (0-9).

        Inputs:
            x: a node with shape (batch_size x 784)
            y: a node with shape (batch_size x 10)
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        return nn.SoftmaxLoss(self.run(x), y)

    def train(self, dataset):
        """
        Trains the model.
        """
        "*** YOUR CODE HERE ***"
        while True:
            for x, y in dataset.iterate_once(self.batch_size):
                loss = self.get_loss(x, y)
                # f(x)=relu (x * W1 + b1) * W2 + b2
                gradient_W1,gradient_b1,gradient_W2,gradient_b2 = nn.gradients(loss, [self.W1, self.b1, self.W2, self.b2])
                self.W1.update(gradient_W1,-1*self.learning_rate)
                self.b1.update(gradient_b1,-1*self.learning_rate)
                self.W2.update(gradient_W2,-1*self.learning_rate)
                self.b2.update(gradient_b2,-1*self.learning_rate)
            # print("本次训练，最终准确度：",dataset.get_validation_accuracy(),end='\n')
            if dataset.get_validation_accuracy() > 0.975:
                return

class LanguageIDModel(object):
    """
    A model for language identification at a single-word granularity.

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # Our dataset contains words from five different languages, and the
        # combined alphabets of the five languages contain a total of 47 unique
        # characters.
        # You can refer to self.num_chars or len(self.languages) in your code
        self.num_chars = 47
        self.languages = ["English", "Spanish", "Finnish", "Dutch", "Polish"]

        # Initialize your model parameters here
        "*** YOUR CODE HERE ***"
        """
                h = hidden layer size (variable, should test different values between 10 and 400)
                b = batch size (Hyperparameter, should evenly divide dataset (here 200))
                """

        # h(0)= x0 * W_x
        # h(i)= xi * W_x + h(i-1) + W_hidden
        # last_out = h(n-1) * W_last
        # 代码保证单个批处理中所有单词都具有相同的长度,单个批处理中单词的长度=self.num_chars 或者 len(self.languages)
        self.input_feature = self.num_chars
        self.output_feature = 5
        self.batches = 200
        self.hidden_layer_size = 200
        self.learning_rate=0.1
        # xi 的输入形状：batches * input_features
        # W_x 的输入形状：input_feature * hidden_layer_size
        # h(i) 实际是由前面的x和W_x计算得到的，它的形状是: batches * hidden_layer_size
        # W_hidden 的形状是：hidden_layer_size * hidden_layer_size
        # 因为现在不能保证最后的输出结果是五维的，所以我们对最后一个h需要做一定的处理，添加一个W_last
        # W_last 的形状为： hidden_layer_size * output_feature
        self.W_x=nn.Parameter(self.input_feature,self.hidden_layer_size)
        self.W_hidden=nn.Parameter(self.hidden_layer_size,self.hidden_layer_size)
        self.W_last=nn.Parameter(self.hidden_layer_size,self.output_feature)

    def run(self, xs):
        """
        Runs the model for a batch of examples.

        Although words have different lengths, our data processing guarantees
        that within a single batch, all words will be of the same length (L).
        虽然单词有不同的长度，但我们的数据保证在单个批处理中，所有单词的长度都相同。

        Here `xs` will be a list of length L. Each element of `xs` will be a
        node with shape (batch_size x self.num_chars), where every row in the
        array is a one-hot vector encoding of a character. //单向量编码
        For example, if we
        have a batch of 8 three-letter words where the last word is "cat", then
        xs[1] will be a node that contains a 1 at position (7, 0). Here the
        index 7 reflects the fact that "cat" is the last word in the batch, and
        the index 0 reflects the fact that the letter "a" is the inital (0th)
        letter of our combined alphabet for this task.

        Your model should use a Recurrent Neural Network to summarize the list
        `xs` into a single node of shape (batch_size x hidden_size), for your
        choice of hidden_size. It should then calculate a node of shape
        (batch_size x 5) containing scores, where higher scores correspond to
        greater probability of the word originating from a particular language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
        Returns:
            A node with shape (batch_size x 5) containing predicted scores
                (also called logits)
        """
        "*** YOUR CODE HERE ***"
        # h(0)= x0 * W_x
        # h(i)= xi * W_x + h(i-1) + W_hidden
        # last_out = h(n-1) * W_last
        for index,x in enumerate(xs):
            if index==0:
                h = nn.ReLU(nn.Linear(x,self.W_x))
            else:
                h=nn.ReLU(nn.Add(nn.Linear(x,self.W_x),nn.Linear(h,self.W_hidden)))
        prediction= nn.Linear(h,self.W_last)
        return prediction


    def get_loss(self, xs, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 5). Each row is a one-hot vector encoding the correct
        language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
            y: a node with shape (batch_size x 5)
        Returns: a loss node
        """
        "*** YOUR CODE HERE ***"
        # prediction =
        # return nn.SquareLoss(self.run(xs), y)
        return nn.SoftmaxLoss(self.run(xs),y)

    def train(self, dataset):
        """
        Trains the model.
        """
        "*** YOUR CODE HERE ***"
        while True:
            for x,y in dataset.iterate_once(self.batches):
                loss=self.get_loss(x,y)
                # h(0)= x0 * W_x
                # h(i)= xi * W_x + h(i-1) + W_hidden
                # last_out = h(n-1) * W_last
                gradient_W_x,gradient_W_hidden,gradient_W_last=nn.gradients(loss,[self.W_x,self.W_hidden,self.W_last])
                self.W_x.update(gradient_W_x,-1*self.learning_rate)
                self.W_hidden.update(gradient_W_hidden,-1*self.learning_rate)
                self.W_last.update(gradient_W_last,-1*self.learning_rate)
            if dataset.get_validation_accuracy()>0.90:
                break

