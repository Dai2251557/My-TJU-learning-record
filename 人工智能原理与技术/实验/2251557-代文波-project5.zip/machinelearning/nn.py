import numpy as np

def format_shape(shape):
    return "x".join(map(str, shape)) if shape else "()"

# Node是所有节点类的基类，包含一个__repr__函数，用于返回节点的类型，形状，内存地址
class Node(object):
    def __repr__(self):
        return "<{} shape={} at {}>".format(
            type(self).__name__, format_shape(self.data.shape), hex(id(self)))

# DataNode类是Parameter、constant类的父类，我们不会直接使用这个类
class DataNode(Node):
    """
    DataNode is the parent class for Parameter and Constant nodes.

    You should not need to use this class directly.
    """
    # 初始化
    def __init__(self, data):
        self.parents = []
        self.data = data

    # 前向传播方法，返回节点的数据
    def _forward(self, *inputs):
        return self.data

    # 反向传播方法，返回一个空列表
    @staticmethod
    def _backward(gradient, *inputs):
        return []

# Parameter 是一个用于存储神经网络（或感知器）中所使用的参数的节点，它继承自DAataNode类
class Parameter(DataNode):
    """
    A Parameter node stores parameters used in a neural network (or perceptron).

    Use the the `update` method to update parameters when training the
    perceptron or neural network.
    在神经网络上训练感知器时，使用update函数来更新parameter类
    """
    # 初始化，这里必须给shape的位置传入一个二维的形状
    def __init__(self, *shape):
        # assert（断言）语句，用来校验一个条件是否为真，
        # 为假则会抛出一个AssertionError异常
        # 对于下面这个assert语句，它用来检验shape是否为2维，
        # 不是的话，会返回一个自定义的错误信息
        assert len(shape) == 2, (
            "Shape must have 2 dimensions, instead has {}".format(len(shape)))
        # 对于下面这个assert语句，它用来检验shape中的每一个元素是否为正的int型数据，
        # 不是的话会返回一个自定义的错误信息
        assert all(isinstance(dim, int) and dim > 0 for dim in shape), (
            "Shape must consist of positive integers, got {!r}".format(shape))
        limit = np.sqrt(3.0 / np.mean(shape))
        data = np.random.uniform(low=-limit, high=limit, size=shape)
        super().__init__(data)

    #w(i,j) <= w(i,j) - alpha * (误差对w(i,j)的偏导)
    #w(i,j) <= w(i,j) + alpha * a(i) * deta(j)
    #multiplier是学习率(alpha)，direction是修正误差(a(i) * deta(j)的结果)
    def update(self, direction, multiplier):
        # 这个assert语句验证direction是一个constant类
        assert isinstance(direction, Constant), (
            "Update direction must be a {} node, instead has type {!r}".format(
                Constant.__name__, type(direction).__name__))
        # 这个assert语句验证direction与当前参数的形状相同
        assert direction.data.shape == self.data.shape, (
            "Update direction shape {} does not match parameter shape "
            "{}".format(
                format_shape(direction.data.shape),
                format_shape(self.data.shape)))
        # 这个assert语句用来检查multiplier是否为int或float类型的数据
        assert isinstance(multiplier, (int, float)), (
            "Multiplier must be a Python scalar, instead has type {!r}".format(
                type(multiplier).__name__))
        self.data += multiplier * direction.data
        # 这个assert语句用Numpy库的isfinite函数来检验self.data是否都是有限数
        assert np.all(np.isfinite(self.data)), (
            "Parameter contains NaN or infinity after update, cannot continue")

# 表示常量节点的类
class Constant(DataNode):
    """
    A Constant node is used to represent:
    * Input features
    * Output labels
    * Gradients computed by back-propagation
    # 一个constant类用于表示（1）输入特征（2）输出标签（3）通过反向传播计算的梯度
    You should not need to construct any Constant nodes directly; they will
    instead be provided by either the dataset or when you call `nn.gradients`
    通常情况下，我们不需要直接构造Constant节点，他们将由数据集提供.或者在你调用`nn.gradients`时提供
    """
    # 初始化
    def __init__(self, data):
        # 这里的assert语句用于检查变量data是否为numpy数组
        assert isinstance(data, np.ndarray), (
            "Data should be a numpy array, instead has type {!r}".format(
                type(data).__name__))
        # 这里的assert语句用于检测Data是否为一个float类型的数组
        assert np.issubdtype(data.dtype, np.floating), (
            "Data should be a float array, instead has data type {!r}".format(
                data.dtype))
        super().__init__(data)

# FunctionNode 是一个表示基于其他节点计算值的类。
# 它继承自 Node 类，用于执行计算梯度所需的必要操作。
class FunctionNode(Node):
    """
    A FunctionNode represents a value that is computed based on other nodes.
    The FunctionNode class performs necessary book-keeping to compute gradients.
    """

    def __init__(self, *parents):
        # assert语句用于检验parents中元素是否都是Node类型
        assert all(isinstance(parent, Node) for parent in parents), (
            "Inputs must be node objects, instead got types {!r}".format(
                tuple(type(parent).__name__ for parent in parents)))
        self.parents = parents
        self.data = self._forward(*(parent.data for parent in parents))

# 这是一个名为Add的类，它继承自FunctionNode。
# 这个类的主要功能是将两个矩阵逐元素相加。
class Add(FunctionNode):
    """
    Adds matrices element-wise.

    Usage: nn.Add(x, y)
    Inputs:
        x: a Node with shape (batch_size x num_features)
        y: a Node with the same shape as x
    Output:
        a Node with shape (batch_size x num_features)
    """
    @staticmethod
    def _forward(*inputs):
        # 检验输入对象是否为两个
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        # 检验两个输入对象的维度是否都是2
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        # 检验两个驶入对象的形状是否一致
        assert inputs[0].shape == inputs[1].shape, (
            "Input shapes should match, instead got {} and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        # 进行相加并返回
        return inputs[0] + inputs[1]

    @staticmethod
    def _backward(gradient, *inputs):
        assert gradient.shape == inputs[0].shape
        return [gradient, gradient]

# 这是一个名为AddBias的类，它继承自FunctionNode。
# 这个类的主要功能是将一个偏置向量添加到每个特征向量上。
class AddBias(FunctionNode):
    """
    Adds a bias vector to each feature vector

    Usage: nn.AddBias(features, bias)
    Inputs:
        features: a Node with shape (batch_size x num_features)
        bias: a Node with shape (1 x num_features)
    Output:
        a Node with shape (batch_size x num_features)
    """
    @staticmethod
    def _forward(*inputs):
        # 检验输入对象是否为两个
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        # 验证两个输入对象的维度是否为2
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        # 验证第二个输入变量（1*m（一行，n列）的偏移量矩阵（bias矩阵））的shape的第一个分量是否为1
        assert inputs[1].shape[0] == 1, (
            "First dimension of second input should be 1, instead got shape "
            "{}".format(format_shape(inputs[1].shape)))

        assert inputs[0].shape[1] == inputs[1].shape[1], (
            "Second dimension of inputs should match, instead got shapes {} "
            "and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        return inputs[0] + inputs[1]

    @staticmethod
    def _backward(gradient, *inputs):
        assert gradient.shape == inputs[0].shape
        return [gradient, np.sum(gradient, axis=0, keepdims=True)]

# 补充：
# dot(a, b, out=None)函数是numpy库中的一个函数，用于计算两个数组的点积。具体来说：
# 如果a和b都是一维数组，那么它是向量的内积（不进行复共轭）。相同位置对应相乘
# 如果a和b都是二维数组，那么它是矩阵乘法，但建议使用matmul或a @ b。
# 如果a或b是0维（标量），那么它等同于multiply，建议使用numpy.multiply(a, b)或直接a * b。
# 如果a是一个N维数组，b是一个一维数组，那么它是a的最后一个轴和b的点积。
# 如果a是一个N维数组，b是一个M维数组（其中M>=2），那么它是a的最后一个轴和b的倒数第二个轴的点积。
#
# 这个类实现了批量点积运算。
# 在神经网络中，批量点积通常用于计算特征向量与权重向量之间的乘积。
class DotProduct(FunctionNode):
    """
    Batched dot product

    Usage: nn.DotProduct(features, weights)
    Inputs:
        features: a Node with shape (batch_size x num_features)
        weights: a Node with shape (1 x num_features)
    Output: a Node with shape (batch_size x 1)
    """

    @staticmethod
    def _forward(*inputs):
        # 下面是检验一些基本条件
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        assert inputs[1].shape[0] == 1, (
            "First dimension of second input should be 1, instead got shape "
            "{}".format(format_shape(inputs[1].shape)))
        assert inputs[0].shape[1] == inputs[1].shape[1], (
            "Second dimension of inputs should match, instead got shapes {} "
            "and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        return np.dot(inputs[0], inputs[1].T)

    @staticmethod
    def _backward(gradient, *inputs):
        # assert gradient.shape[0] == inputs[0].shape[0]
        # assert gradient.shape[1] == 1
        # return [np.dot(gradient, inputs[1]), np.dot(gradient.T, inputs[0])]
        raise NotImplementedError(
            "Backpropagation through DotProduct nodes is not needed in this "
            "assignment")

# 这是一个名为Linear的类，它继承自FunctionNode。
# 这个类的主要功能是实现线性变换（矩阵乘法），将输入数据与权重进行矩阵乘法运算，得到输出结果。
class Linear(FunctionNode):
    """
    Applies a linear transformation (matrix multiplication) to the input

    Usage: nn.Linear(features, weights)
    Inputs:
        features: a Node with shape (batch_size x input_features)
        weights: a Node with shape (input_features x output_features)
    Output: a node with shape (batch_size x output_features)
    """
    @staticmethod
    def _forward(*inputs):
        # 检验一些基本条件
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        # 检验左行等于右列
        assert inputs[0].shape[1] == inputs[1].shape[0], (
            "Second dimension of first input should match first dimension of "
            "second input, instead got shapes {} and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        return np.dot(inputs[0], inputs[1])

    @staticmethod
    def _backward(gradient, *inputs):
        assert gradient.shape[0] == inputs[0].shape[0]
        assert gradient.shape[1] == inputs[1].shape[1]
        return [np.dot(gradient, inputs[1].T), np.dot(inputs[0].T, gradient)]

# 一个名为ReLU（Rectified Linear Unit）的Python类，它是一个用于实现激活函数的类。
# ReLU激活函数是一种常用的非线性激活函数，其公式为：f(x) = max(0, x)。
# 这意味着当输入值为负数时，输出值为0；当输入值为正数时，输出值等于输入值。（主要功能）
# 这个激活函数在神经网络中被广泛使用，因为它可以增加网络的非线性，从而提高模型的表达能力。
class ReLU(FunctionNode):
    """
    An element-wise Rectified Linear Unit nonlinearity: max(x, 0).
    This nonlinearity replaces all negative entries in its input with zeros.

    Usage: nn.ReLU(x)
    Input:
        x: a Node with shape (batch_size x num_features)
    Output: a Node with the same shape as x, but no negative entries
    """
    @staticmethod
    def _forward(*inputs):
        assert len(inputs) == 1, "Expected 1 input, got {}".format(len(inputs))
        assert inputs[0].ndim == 2, (
            "Input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        return np.maximum(inputs[0], 0)

    @staticmethod
    def _backward(gradient, *inputs):
        assert gradient.shape == inputs[0].shape
        return [gradient * np.where(inputs[0] > 0, 1.0, 0.0)]

# SquareLoss是一个自定义的损失函数类，继承自FunctionNode。
# 它的作用是计算两个输入矩阵（a和b）之间的平方损失。
# 具体来说，它会先计算所有位置(i, j)上的0.5 * (a[i, j] - b[i, j])^2，然后返回这个矩阵的均值。
class SquareLoss(FunctionNode):
    """
    This node first computes 0.5 * (a[i,j] - b[i,j])**2 at all positions (i,j)
    in the inputs, which creates a (batch_size x dim) matrix. It then calculates
    and returns the mean of all elements in this matrix.

    Usage: nn.SquareLoss(a, b)
    Inputs:
        a: a Node with shape (batch_size x dim)
        b: a Node with shape (batch_size x dim)
    Output: a scalar Node (containing a single floating-point number)
    """
    @staticmethod
    def _forward(*inputs):
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        assert inputs[0].shape == inputs[1].shape, (
            "Input shapes should match, instead got {} and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        return np.mean(np.square(inputs[0] - inputs[1]) / 2)

    @staticmethod
    def _backward(gradient, *inputs):
        assert np.asarray(gradient).ndim == 0
        return [
            gradient * (inputs[0] - inputs[1]) / inputs[0].size,
            gradient * (inputs[1] - inputs[0]) / inputs[0].size
        ]

# 这是一个名为SoftmaxLoss的类，继承自FunctionNode。
# 它用于计算批量softmax损失，主要用于分类问题。
# 这个类有三个静态方法：log_softmax、_forward和_backward。
# log_softmax方法：
# 对输入的logits进行log_softmax操作，即先减去每行的最大值，然后对每个元素取指数，再求和，最后取对数。
# _forward方法：
# 计算softmax损失的前向传播。首先检查输入的合法性，然后计算log_probs，最后返回平均损失。
# _backward方法：
# 计算softmax损失的反向传播。首先检查梯度的合法性，然后计算梯度，最后返回两个梯度。
class SoftmaxLoss(FunctionNode):
    """
    A batched softmax loss, used for classification problems.

    IMPORTANT: do not swap the order of the inputs to this node!

    Usage: nn.SoftmaxLoss(logits, labels)
    Inputs:
        logits: a Node with shape (batch_size x num_classes). Each row
            represents the scores associated with that example belonging to a
            particular class. A score can be an arbitrary real number.
        labels: a Node with shape (batch_size x num_classes) that encodes the
            correct labels for the examples. All entries must be non-negative
            and the sum of values along each row should be 1.
    Output: a scalar Node (containing a single floating-point number)
    """
    @staticmethod
    def log_softmax(logits):
        log_probs = logits - np.max(logits, axis=1, keepdims=True)
        log_probs -= np.log(np.sum(np.exp(log_probs), axis=1, keepdims=True))
        return log_probs

    @staticmethod
    def _forward(*inputs):
        assert len(inputs) == 2, "Expected 2 inputs, got {}".format(len(inputs))
        assert inputs[0].ndim == 2, (
            "First input should have 2 dimensions, instead has {}".format(
                inputs[0].ndim))
        assert inputs[1].ndim == 2, (
            "Second input should have 2 dimensions, instead has {}".format(
                inputs[1].ndim))
        assert inputs[0].shape == inputs[1].shape, (
            "Input shapes should match, instead got {} and {}".format(
                format_shape(inputs[0].shape), format_shape(inputs[1].shape)))
        assert np.all(inputs[1] >= 0), (
            "All entries in the labels input must be non-negative")
        assert np.allclose(np.sum(inputs[1], axis=1), 1), (
            "Labels input must sum to 1 along each row")
        log_probs = SoftmaxLoss.log_softmax(inputs[0])
        return np.mean(-np.sum(inputs[1] * log_probs, axis=1))

    @staticmethod
    def _backward(gradient, *inputs):
        assert np.asarray(gradient).ndim == 0
        log_probs = SoftmaxLoss.log_softmax(inputs[0])
        return [
            gradient * (np.exp(log_probs) - inputs[1]) / inputs[0].shape[0],
            gradient * -log_probs / inputs[0].shape[0]
        ]

# 这个函数gradients用于计算损失函数关于给定参数的梯度。
# 它接受两个输入参数：
# 一个损失节点（可以是SquareLoss或SoftmaxLoss类型）和一个包含Parameter节点的列表。
# 输出是一个Constant对象列表，表示损失函数相对于每个提供的参数的梯度。
def gradients(loss, parameters):
    """
    Computes and returns the gradient of the loss with respect to the provided
    parameters.

    Usage: nn.gradients(loss, parameters)
    Inputs:
        loss: a SquareLoss or SoftmaxLoss node
        parameters: a list (or iterable) containing Parameter nodes
    Output: a list of Constant objects, representing the gradient of the loss
        with respect to each provided parameter.
    """

    assert isinstance(loss, (SquareLoss, SoftmaxLoss)), (
        "Loss must be a loss node, instead has type {!r}".format(
            type(loss).__name__))
    assert all(isinstance(parameter, Parameter) for parameter in parameters), (
        "Parameters must all have type {}, instead got types {!r}".format(
            Parameter.__name__,
            tuple(type(parameter).__name__ for parameter in parameters)))
    assert not hasattr(loss, "used"), (
        "Loss node has already been used for backpropagation, cannot reuse")

    loss.used = True

    nodes = set()
    tape = []

    def visit(node):
        if node not in nodes:
            for parent in node.parents:
                visit(parent)
            nodes.add(node)
            tape.append(node)

    visit(loss)
    nodes |= set(parameters)

    grads = {node: np.zeros_like(node.data) for node in nodes}
    grads[loss] = 1.0

    for node in reversed(tape):
        parent_grads = node._backward(
            grads[node], *(parent.data for parent in node.parents))
        for parent, parent_grad in zip(node.parents, parent_grads):
            grads[parent] += parent_grad

    return [Constant(grads[parameter]) for parameter in parameters]

# 这段代码定义了一个名为as_scalar的函数，
# 它接受一个名为node的参数。
# 这个函数的主要目的是将一个具有单个元素的节点（Node）的值转换为标准的Python数字。
# 这对于只有一个元素的节点（如SquareLoss和SoftmaxLoss，以及批量大小为1元素的DotProduct）是有效的。
def as_scalar(node):
    """
    Returns the value of a Node as a standard Python number. This only works
    for nodes with one element (e.g. SquareLoss and SoftmaxLoss, as well as
    DotProduct with a batch size of 1 element).
    """

    assert isinstance(node, Node), (
        "Input must be a node object, instead has type {!r}".format(
            type(node).__name__))
    assert node.data.size == 1, (
        "Node has shape {}, cannot convert to a scalar".format(
            format_shape(node.data.shape)))
    if type(node.data) is np.ndarray:
        return np.ndarray.item(node.data)
    else:
        return np.float64.item(node.data)
    # return np.ndarray.item(node.data)

  # return np.asscalar(node.data)//文件版本问题，自己修改第一处
