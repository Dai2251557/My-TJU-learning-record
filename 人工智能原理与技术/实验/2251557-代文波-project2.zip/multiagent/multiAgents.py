# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
import sys
import math
from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        #针对鬼魂的评分
        ghost_score=0
        # 用一个列表来存储所有ghost到当前位置的距离
        ghost_distance=list()
        # 计算所有ghost距离当前位置的曼哈顿距离
        for ghost in newGhostStates:
            ghost_distance.append(manhattanDistance(ghost.configuration.pos,newPos))
        #评判吃豆人和ghost的最小曼哈顿距离,距离越小，置ghost_score越低即可，
        # 这里我尝试过使用正比例函数，但是因为性能太差，最后放弃了，所以最终选择了规定范围给负值的方法
        # ghost_score=math.exp(min(ghost_distance))#性能太差，放弃了
        # ghost_score=min(ghost_distance)#只通过一半的测试
        # ghost_score=min(ghost_distance)**2
        if min(ghost_distance)<2:
            ghost_score=-700
        else:
            ghost_score=0

        #针对食物（豆子）的评分
        food_score = 0
        # 将食物状态转换为列表，方便之后遍历寻找距离最小点
        foods = newFood.asList()
        # 用一个列表来存储所有豆子到当前位置的距离
        food_distance=list()
        #如果迷宫中还有豆子存在，就进行if分支修改food_score,否则就让food_score=0不变即可
        if foods!=list():
            #计算所有剩余豆子与吃豆人的曼哈顿距离
           for food in foods:
               food_distance.append(manhattanDistance(food,newPos))
            #这里的food_score和豆子与吃豆人之间最小的曼哈顿距离成反比，我设置为了ex(-x)的模式
           food_score=(math.exp(-min(food_distance)))*10
        # 最后把下一个状态的得分也计入评价值结果
        return successorGameState.getScore() + ghost_score + food_score

def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """
    # getMax 出吃豆人角度出发给出最佳的动作选择
    def getMax(self, gameState, depth=0, agentIndex=0):
        # 如果当前深度已经到达了目标的搜索深度，则终止递归，返回当前状态的评估值
        # 如果当前状态没有合法的行动(即合法行动的列表为空)，就终止递归，返回当前状态的评估值
        if depth==self.depth or gameState.getLegalActions(agentIndex)==list():
            return self.evaluationFunction(gameState),None
        max_value=-sys.maxsize
        best_action=None
        # 吃豆人这里只需要根据鬼怪们的行动选出自己的最佳动作即可
        for action in gameState.getLegalActions(agentIndex):
            # 根据本层中所有鬼魂的评估分数选出最大的评估分数
            value = self.getMin(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1)[0]
            #更新评估分数最大值、最佳动作
            if value>max_value:
                max_value=value
                best_action=action
        return max_value,best_action

    # getMin从鬼魂角度出发，给出最佳的动作选择
    def getMin(self, gameState, depth=0, agentIndex=1):
        # 如果达到搜索深度，则将当前状态的评价值返回
        # 如果接下来没有可行的行动，也要终止迭代
        if depth==self.depth or gameState.getLegalActions(agentIndex)==list():
            return self.evaluationFunction(gameState),None
        min_value=sys.maxsize
        best_action=None
        # 每个鬼怪这里需要根据吃豆人的行动选出自己的最佳动作，最后所有鬼怪都需要综合考虑以获取整体的最佳动作
        for action in gameState.getLegalActions(agentIndex):
            if agentIndex == gameState.getNumAgents() - 1:
                # 根据下一层吃豆人的动作选择最小的评估分数
                value = self.getMax(gameState.generateSuccessor(agentIndex, action), depth + 1, 0)[0]
            else:
                # 将本层中所有鬼魂的动作都加以考虑，综合取评估分数最小值
                value = self.getMin(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1)[0]
            # 更新评估分数最小值、最佳动作
            if value<min_value:
                min_value=value
                best_action=action
        return min_value,best_action

    def getAction(self, gameState: GameState):
        "*** YOUR CODE HERE ***"
        best_action=self.getMax(gameState)[1]
        return best_action
    #util.raiseNotDefined()



class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """
    # getMax主要是计算吃豆人选择最佳的动作
    def getMax(self, gameState, depth=0, agentIndex=0, alpha=-sys.maxsize, beta=sys.maxsize):
        # 如果达到搜索深度，则将当前状态的评价值返回
        # 如果接下来没有可行的行动，也要终止迭代
        if depth==self.depth or gameState.getLegalActions(agentIndex)==list():
            return self.evaluationFunction(gameState),None
        max_value=-sys.maxsize
        best_action = None
        # 吃豆人这里只需要根据鬼怪们的行动选出自己的最佳动作即可
        for action in gameState.getLegalActions(agentIndex):
            # 根据本层中所有鬼魂的评估分数选出最大的评估分数
            value = self.getMin(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1, alpha, beta)[0]
            #value>beta，即出现了value>=beta>=alpha的情况，该节点不需要再考虑了，直接返回当前情况
            if value > beta:
                return value, action
            #更新最大评估分数和最佳动作
            if value >max_value:
                max_value=value
                best_action = action
            #更新alpha值
            alpha=max(alpha,value)
        return max_value,best_action

    # getMin用于计算鬼怪选择造成最坏影响的动作，所以agentIndex从一开始
    def getMin(self, gameState, depth=0, agentIndex=1, alpha=-sys.maxsize, beta=sys.maxsize):
        # 如果达到搜索深度，则将当前状态的评价值返回
        # 如果接下来没有可行的行动，也要终止迭代
        if depth==self.depth or gameState.getLegalActions(agentIndex)==list():
            return self.evaluationFunction(gameState),None
        min_value=sys.maxsize
        best_action = None
        # 每个鬼怪这里需要根据吃豆人的行动选出自己的最佳动作，最后所有鬼怪都需要综合考虑以获取整体的最佳动作
        for action in gameState.getLegalActions(agentIndex):
            if agentIndex == gameState.getNumAgents() - 1:
                # 根据下一层吃豆人的评估分数选择最小的评估分数
                value = self.getMax(gameState.generateSuccessor(agentIndex, action), depth + 1, 0, alpha, beta)[0]
            else:
                # 将本层中所有鬼魂的动作都加以考虑，综合取评估分数最小值
                value = self.getMin(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1, alpha, beta)[0]
            # value<alpha，即出现了value<=alpha<=beta的情况，该节点不需要再考虑了，直接返回当前情况
            if value < alpha:
                return value, action
            #更新评估分数最小值、最佳动作
            if value < min_value:
                min_value = value
                best_action = action
            #更新beta值
            beta= min(value,beta)
        return min_value, best_action

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        # 一开始肯定是先从吃豆人的行动开始，所以直接调用getMax函数
        best_action = self.getMax(gameState)[1]
        return best_action
        # util.raiseNotDefined()




class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """
    # 与Minimax算法一样，getMax主要是计算吃豆人的最佳行动
    def getMax(self, gameState, depth=0, agentIndex=0):
        # 如果达到搜索深度，则将当前状态的评价值返回
        # 如果接下来吃豆人已经没有可行的行动，也要终止迭代
        if depth == self.depth or gameState.getLegalActions(agentIndex) == list():
            return self.evaluationFunction(gameState), None
        # 获得吃豆人的所有可行操作，并进行遍历
        max_value = -sys.maxsize
        best_action = None
        # 吃豆人这里只需要根据鬼怪们的行动选出自己的最佳动作即可
        for action in gameState.getLegalActions(agentIndex):
            # 根据本层中所有鬼魂的评估分数选出最大的评估分数
            value = self.my_expect(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1)
            # 更新评估分数最大值、最佳动作
            if value > max_value:
                max_value = value
                best_action = action
        return max_value, best_action

    # my_expect主要是计算鬼怪选择造成影响的状态的效用值，即各种可能的状态的效用值平均
    def my_expect(self, gameState, depth, agentIndex=1):
        # 如果达到搜索深度，则将当前状态的评价值返回
        # 如果接下来没有可行的行动，也要终止迭代
        if depth == self.depth or gameState.getLegalActions(agentIndex) == list():
            return self.evaluationFunction(gameState)
        # 获得当前鬼怪的所有可行操作，并进行遍历,求所有评估分数的平均值
        total_value = 0
        sum_move = 0
        for action in gameState.getLegalActions(agentIndex):
            sum_move += 1
            # 如果当前是最后一个鬼怪的agent，那么下一次轮到吃豆人
            if agentIndex == gameState.getNumAgents() - 1:
                #鬼魂计算完毕，接下来计算吃豆人的评估分数
                value = self.getMax(gameState.generateSuccessor(agentIndex, action), depth + 1, 0)[0]
                total_value += value
            else:
                # 鬼魂尚未计算完毕，接下来仍然计算其他鬼魂的评估分数
                value = self.my_expect(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1)
                total_value += value
        # 求平均值返回
        return total_value / sum_move

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        best_action=self.getMax(gameState)[1]
        return best_action
        #util.raiseNotDefined()

def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    # 获得计算需要的初始信息，包括吃豆人位置、食物状态、药丸状态、幽灵状态
    pacman_position = currentGameState.getPacmanPosition()
    foods = currentGameState.getFood().asList()
    ghosts = currentGameState.getGhostStates()
    capsules = currentGameState.getCapsules()

    # 先计算最近的食物对吃豆人的影响
    food_score=0
    food_distance=list()
    if foods!=list():
        for food in foods:
            # 计算食物点到吃豆人当前位置的曼哈顿距离
            food_distance.append(manhattanDistance(food,pacman_position))
        # 求食物与吃豆人曼哈顿距离的最小值
        min_food_distance=min(food_distance)
        # 根据评估函数计算food_score
        food_score=math.exp(-min_food_distance)

    # 计算最近的药丸对吃豆人的影响
    capsule_score=0
    capsule_distance=list()
    if capsules!=list():
        for capsule in capsules:
            # 计算药丸位置到吃豆人当前位置的曼哈顿距离
            capsule_distance.append(manhattanDistance(capsule,pacman_position))
        # 计算吃豆人与药丸曼哈顿距离的最小值
        min_capsule_distance=min(capsule_distance)
        # 根据评估函数计算capsule_score
        capsule_score=math.exp(-min_capsule_distance)

    # 计算鬼魂对吃豆人的影响
    ghost_score=0
    ghost_distance=list()
    if ghosts!=list():
        for ghost in ghosts:
            # 计算鬼魂位置到吃豆人距离的曼哈顿距离
            ghost_distance.append(manhattanDistance(ghost.configuration.pos,pacman_position))
        # 计算吃豆人与鬼魂曼哈顿距离的最小值
        min_ghost_distance=min(ghost_distance)
        # 根据评估函数计算ghost_score
        if min_ghost_distance<2:
            ghost_score=-700

    # 计算鬼魂惊吓状态对吃豆人的影响
    scaredtime_score=0
    scaredtime=list()
    for ghost in ghosts:
        # 统计所有幽灵的恐慌时间
        scaredtime.append(ghost.scaredTimer)
    # 根据评估函数计算scaredtime_score
    scaredtime_score=max(scaredtime)
    # 最后把下一个状态的得分也计入评价值结果
    return currentGameState.getScore() + food_score + ghost_score + scaredtime_score + capsule_score

#Abbreviation
better = betterEvaluationFunction
